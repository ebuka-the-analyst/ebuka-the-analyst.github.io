import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Mail,
  Phone,
  MapPin,
  ExternalLink,
  Download,
  BarChart3,
  TrendingUp,
  PieChart,
  Calculator,
  Database,
  FileSpreadsheet,
} from "lucide-react"

export default function Portfolio() {
  const projects = [
    {
      id: 1,
      title: "Sales Performance Dashboard",
      description:
        "Comprehensive sales analysis with pivot tables, charts, and KPI tracking for quarterly performance review.",
      skills: ["Pivot Tables", "Charts", "KPIs", "Data Visualization"],
      icon: <BarChart3 className="h-6 w-6" />,
      category: "Dashboard",
    },
    {
      id: 2,
      title: "Financial Budget Model",
      description:
        "Dynamic budget forecasting model with scenario analysis and variance reporting for strategic planning.",
      skills: ["Financial Modeling", "Forecasting", "Scenario Analysis", "Formulas"],
      icon: <Calculator className="h-6 w-6" />,
      category: "Financial Analysis",
    },
    {
      id: 3,
      title: "Customer Segmentation Analysis",
      description:
        "RFM analysis and customer clustering using advanced Excel functions to identify high-value segments.",
      skills: ["RFM Analysis", "Clustering", "Advanced Functions", "Segmentation"],
      icon: <PieChart className="h-6 w-6" />,
      category: "Customer Analytics",
    },
    {
      id: 4,
      title: "Inventory Management System",
      description: "Automated inventory tracking with reorder alerts, ABC analysis, and supplier performance metrics.",
      skills: ["Automation", "ABC Analysis", "Conditional Formatting", "Data Validation"],
      icon: <Database className="h-6 w-6" />,
      category: "Operations",
    },
    {
      id: 5,
      title: "Market Trend Analysis",
      description: "Time series analysis of market data with trend identification and predictive modeling using Excel.",
      skills: ["Time Series", "Trend Analysis", "Regression", "Forecasting"],
      icon: <TrendingUp className="h-6 w-6" />,
      category: "Market Research",
    },
    {
      id: 6,
      title: "HR Analytics Dashboard",
      description:
        "Employee performance tracking, turnover analysis, and recruitment metrics with interactive dashboards.",
      skills: ["HR Metrics", "Performance Tracking", "Interactive Dashboards", "Data Analysis"],
      icon: <FileSpreadsheet className="h-6 w-6" />,
      category: "Human Resources",
    },
    {
      id: 7,
      title: "Supply Chain Optimization",
      description: "Cost analysis and optimization model for supply chain efficiency with supplier comparison matrix.",
      skills: ["Cost Analysis", "Optimization", "Supplier Analysis", "Process Improvement"],
      icon: <BarChart3 className="h-6 w-6" />,
      category: "Supply Chain",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground font-[family-name:var(--font-heading)]">
                Alex Johnson
              </h1>
              <p className="text-lg text-muted-foreground mt-1">Data Analyst | Excel Specialist</p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Resume
              </Button>
              <Button className="bg-primary hover:bg-primary/90">
                <Mail className="h-4 w-4 mr-2" />
                Contact Me
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-foreground mb-6 font-[family-name:var(--font-heading)]">
            Transforming Data into Actionable Insights
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8 leading-relaxed">
            Experienced data analyst with expertise in Excel-based solutions for business intelligence, financial
            modeling, and operational optimization. Proven track record of delivering data-driven insights that drive
            strategic decision-making.
          </p>
          <Button size="lg" className="bg-accent hover:bg-accent/90">
            View My Projects
          </Button>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4 font-[family-name:var(--font-heading)]">
              Featured Excel Projects
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              A showcase of comprehensive data analysis projects demonstrating advanced Excel skills and business acumen
              across various industries and functions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <Card key={project.id} className="hover:shadow-lg transition-shadow duration-300 border-border">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-accent/10 rounded-lg text-accent">{project.icon}</div>
                    <Badge variant="secondary" className="text-xs">
                      {project.category}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl font-[family-name:var(--font-heading)]">{project.title}</CardTitle>
                  <CardDescription className="text-sm leading-relaxed">{project.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.skills.map((skill, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                  <Button variant="outline" size="sm" className="w-full bg-transparent">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    View Project
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-6 font-[family-name:var(--font-heading)]">
                About Me
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                With over 5 years of experience in data analysis and business intelligence, I specialize in creating
                sophisticated Excel-based solutions that transform raw data into strategic insights. My expertise spans
                financial modeling, operational analytics, and dashboard development.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <BarChart3 className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Advanced Excel Skills</h3>
                    <p className="text-sm text-muted-foreground">Pivot Tables, VBA, Power Query, Advanced Formulas</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <TrendingUp className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Business Intelligence</h3>
                    <p className="text-sm text-muted-foreground">KPI Development, Dashboard Design, Reporting</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Calculator className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Financial Modeling</h3>
                    <p className="text-sm text-muted-foreground">Forecasting, Budgeting, Scenario Analysis</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-center">
              <div className="w-80 h-80 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl flex items-center justify-center">
                <img
                  src="/data-analyst-headshot.png"
                  alt="Professional headshot"
                  className="w-72 h-72 rounded-xl object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-foreground mb-6 font-[family-name:var(--font-heading)]">
              Let's Work Together
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Ready to turn your data into actionable insights? I'd love to discuss how my Excel expertise can help
              drive your business forward.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="flex flex-col items-center p-6 bg-card rounded-lg border border-border">
                <Mail className="h-8 w-8 text-accent mb-3" />
                <h3 className="font-semibold text-foreground mb-2">Email</h3>
                <p className="text-sm text-muted-foreground">alex.johnson@email.com</p>
              </div>
              <div className="flex flex-col items-center p-6 bg-card rounded-lg border border-border">
                <Phone className="h-8 w-8 text-accent mb-3" />
                <h3 className="font-semibold text-foreground mb-2">Phone</h3>
                <p className="text-sm text-muted-foreground">+1 (555) 123-4567</p>
              </div>
              <div className="flex flex-col items-center p-6 bg-card rounded-lg border border-border">
                <MapPin className="h-8 w-8 text-accent mb-3" />
                <h3 className="font-semibold text-foreground mb-2">Location</h3>
                <p className="text-sm text-muted-foreground">New York, NY</p>
              </div>
            </div>

            <Button size="lg" className="bg-primary hover:bg-primary/90">
              <Mail className="h-5 w-5 mr-2" />
              Get In Touch
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground">
            © 2024 Alex Johnson. All rights reserved. | Built to showcase Excel expertise and data analysis skills.
          </p>
        </div>
      </footer>
    </div>
  )
}
